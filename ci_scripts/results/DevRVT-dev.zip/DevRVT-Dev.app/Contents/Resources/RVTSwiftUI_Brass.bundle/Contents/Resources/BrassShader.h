//
//  BrassShader.h
//  
//
//  Created by gandreas on 9/2/22.
//

#ifndef BrassShader_h
#define BrassShader_h
#include <metal_stdlib>
using namespace metal;

typedef struct {
    float4 renderedCoordinate [[position]];
    float2 textureCoordinate;
} TextureMappingVertex;


float3 toHSV(float3 rgb);

float reminder(float value, float divider);

float3 hsvToRGB(float3 hsv);

float hue2rgb(float p, float q, float t);

float3 toHSL(float3 rgb);

float3 hslToRGB(float3 hsl);

float4 satBright(float4 rgba, float saturation, float brightness);

float3 hslAdjust(float3 pixelColor, float dh, float ds, float dl);

float convertCalibratedToLinear(float c);
float convertLinearToCalibrated(float c);
float3 convertSRGBToRGB(float3 srgb);
float3 convertRGBToSRGB(float3 srgb);

void assertIf(bool x);

float grayscale(float3 rgb);

// standard "blend mode"
float4 blend(float4 background, float4 foreground, float blend);

#endif /* BrassShader_h */
